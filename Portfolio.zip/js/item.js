function item1(){
    document.getElementById("item1").style.display = 'block';
    document.getElementById("item2").style.display = 'none';
    document.getElementById("item3").style.display = 'none';
    document.getElementById("item4").style.display = 'none';
}

function item2(){
    document.getElementById("item1").style.display = 'none';
    document.getElementById("item2").style.display = 'block';
    document.getElementById("item3").style.display = 'none';
    document.getElementById("item4").style.display = 'none';
}

function item3(){
    document.getElementById("item1").style.display = 'none';
    document.getElementById("item2").style.display = 'none';
    document.getElementById("item3").style.display = 'block';
    document.getElementById("item4").style.display = 'none';
}

function item4(){
    document.getElementById("item1").style.display = 'none';
    document.getElementById("item2").style.display = 'none';
    document.getElementById("item3").style.display = 'none';
    document.getElementById("item4").style.display = 'block';
}