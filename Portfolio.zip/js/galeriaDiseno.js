function galeria1(){
    document.getElementById("galeria1").style.display = 'block';
    document.getElementById("galeria2").style.display = 'none';
    document.getElementById("galeria3").style.display = 'none';
    document.getElementById("galeria4").style.display = 'none';
}

function galeria2(){
    document.getElementById("galeria1").style.display = 'none';
    document.getElementById("galeria2").style.display = 'block';
    document.getElementById("galeria3").style.display = 'none';
    document.getElementById("galeria4").style.display = 'none';
}

function galeria3(){
    document.getElementById("galeria1").style.display = 'none';
    document.getElementById("galeria2").style.display = 'none';
    document.getElementById("galeria3").style.display = 'block';
    document.getElementById("galeria4").style.display = 'none';
}

function galeria4(){
    document.getElementById("galeria1").style.display = 'none';
    document.getElementById("galeria2").style.display = 'none';
    document.getElementById("galeria3").style.display = 'none';
    document.getElementById("galeria4").style.display = 'block';
}